const funcioncita = () => {
  return "Holis, soy una funcion de prueba para probar imports dentro del handler";
};

module.exports = funcioncita;
